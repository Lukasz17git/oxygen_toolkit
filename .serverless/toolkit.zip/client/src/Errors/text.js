
export default {
    title: {
        esp: 'Error',
        eng: 'Error'
    },
    location: {
        esp: 'Lugar:',
        eng: 'Location: '
    },
    field: {
        esp: 'En:',
        eng: 'In:'
    },
    type: {
        esp: 'Tipo de error:',
        eng: 'Error type:'
    }
}