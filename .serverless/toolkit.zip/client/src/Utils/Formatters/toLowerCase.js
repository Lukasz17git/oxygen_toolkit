const toLowerCase = (name) => {
    return name ? name.toLowerCase() : name
}
export default toLowerCase