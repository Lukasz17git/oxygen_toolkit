
export const cancel = {
    esp: 'Cancelar',
    eng: 'Cancel'
}

export const back = {
    esp: 'Atrás',
    eng: 'Back'
}
