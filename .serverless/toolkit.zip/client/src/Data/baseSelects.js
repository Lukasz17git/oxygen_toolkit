
export const deletedValueText = {
    esp: 'La opción seleccionada fue eliminada',
    eng: 'Selected option has been removed'
}

export default {
    converterSelectedUnits: {
        placeholder: {
            esp: 'Unidades',
            eng: 'Units'
        },
        options: null,
        optionsMap: null
    },

}