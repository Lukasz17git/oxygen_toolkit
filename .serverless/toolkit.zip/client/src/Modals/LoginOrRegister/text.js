export default {
    title: {
        esp: 'Cuenta',
        eng: 'Account'
    },
    mainLabel: {
        esp: 'No te encuentras logueado. ¿Qué te gustaría hacer?',
        eng: 'You are not logued in. What would you like to do?'
    },
    login: {
        esp: 'Loguear',
        eng: 'Login'
    },
    register: {
        esp: 'Registrar',
        eng: 'Register'
    }
}