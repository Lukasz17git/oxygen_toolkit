export default {
    title: {
        esp: 'Desloguear',
        eng: 'Logout'
    },
    mainLabel: {
        esp: 'Estás seguro de querer desloguear?',
        eng: 'Are you sure about log-in out?'
    },
    submit: {
        esp: 'Desloguear',
        eng: 'Logout'
    }
}