
export default {
    title: {
        esp: 'Cuenta',
        eng: 'Account'
    },
    logout: {
        esp: 'cerrar sesión',
        eng: 'logout'
    },
    conversionsLength: {
        esp: 'Conversiones guardadas',
        eng: 'Conversions saved'
    },
    palettesLength: {
        esp: 'Paletas guardadas',
        eng: 'Palettes saved'
    }
}