export default {
    title: {
        esp: 'Inicio sesión',
        eng: 'Sign-in'
    },
    mainLabel: {
        esp: 'Introduce tus datos de acceso:',
        eng: 'Enter your access data:'
    },
    submit: {
        esp: 'Acceder',
        eng: 'Access'
    },
}