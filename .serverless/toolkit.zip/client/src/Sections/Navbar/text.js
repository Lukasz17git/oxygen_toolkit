export default {
    converter: {
        esp: 'Conversor de Unidades',
        eng: 'Unit Converter'
    },
    palette: {
        esp: 'Paleta de Colores',
        eng: 'Color Palette'
    }
}