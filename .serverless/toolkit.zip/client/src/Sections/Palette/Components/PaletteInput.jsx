const PaletteInput = () => {
  return (
    <div>PaletteInput</div>
  )
}
export default PaletteInput