export default {
    title: {
        esp: 'Generador de Paleta de Colores',
        eng: 'Color Palette Generator'
    },
    savedTitle: {
        esp: 'Paletas Guardadas',
        eng: 'Saved Palettes'
    }
}