const FooterLink = ({ text }) => {
    return (
        <button className="footer-link">{text}</button>
    )
}
export default FooterLink