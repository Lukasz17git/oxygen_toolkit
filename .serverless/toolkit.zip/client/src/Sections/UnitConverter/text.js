export default {
    title: {
        esp: 'Convertidor de Unidades',
        eng: 'Unit Converter'
    },
    savedTitle: {
        esp: 'Guardados',
        eng: 'Saved'
    }
}