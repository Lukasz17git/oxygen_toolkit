export const initialRoute = 'converter' //palette, converter
