
export const initialModal = {
    id: '',
    data: null
}
