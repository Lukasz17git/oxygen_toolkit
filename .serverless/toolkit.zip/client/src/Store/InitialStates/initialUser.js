export const initialUser = {
    _id: '', //_id will be used to check locally if the user is authenticated (only locally, server still manages if the user is authenticated correctly)
    email: '',
    username: '',
    password: '',
    repeatPassword: '',
}